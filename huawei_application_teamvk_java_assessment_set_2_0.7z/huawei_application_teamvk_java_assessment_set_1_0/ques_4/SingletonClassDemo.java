package ques_4;

public class SingletonClassDemo {
	
	//Write a singleton class.

	
	private static SingletonClassDemo singletonClassDemo = null;
	public String s;
	
	
	private SingletonClassDemo(){
		s = "wipro limited ";
	}
	
	public static SingletonClassDemo getInstance(){
		if(singletonClassDemo == null){
			singletonClassDemo = new SingletonClassDemo();
		}
		
	    return singletonClassDemo;
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
          
		SingletonClassDemo instance_A = SingletonClassDemo.getInstance();
		SingletonClassDemo instance_B = SingletonClassDemo.getInstance();
		SingletonClassDemo instance_C = SingletonClassDemo.getInstance();
		
		  instance_A.s = (instance_A.s).toUpperCase();
		  System.out.println("String value from instance A is: "+instance_A.s);
		  System.out.println("String value from instance B is: "+instance_B.s);
		  System.out.println("String value from instance C is: "+instance_C.s);
	}
	

}
