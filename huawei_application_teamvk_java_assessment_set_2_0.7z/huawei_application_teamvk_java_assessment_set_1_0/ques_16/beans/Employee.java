package beans;

public class Employee {

	private String name;
	private String sal;

	public Employee(String name, String sal) {
		super();
		this.name = name;
		this.sal = sal;
	}

	@Override
	public String toString() {
		return "Employee [name=" + name + ", sal=" + sal + "]";
	}

}
