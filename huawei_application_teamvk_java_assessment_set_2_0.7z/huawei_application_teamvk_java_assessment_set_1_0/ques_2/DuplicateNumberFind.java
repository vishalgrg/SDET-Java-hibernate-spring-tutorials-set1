package ques_2;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class DuplicateNumberFind {
	
	// Find out duplicate number between 1 to N numbers.

	public  Set<Integer> findDuplicateInArray(int... arr) {
	    Set<Integer> unique = new HashSet<>();
	    Set<Integer> duplicate = new HashSet<>();

	    for (int val : arr)
	        (unique.contains(val) ? duplicate : unique).add(val);

	    return duplicate;
	}

	public static void main(String[] args) {
		int arr[] = {50,4,3,90,90,10,2,5};
		DuplicateNumberFind duplicateNumberFind = new DuplicateNumberFind();
		System.out.println("given array:- ");
		for (int i : arr) {
			System.out.print(" "+i);
		}
		
		System.out.println(" ");

		System.out.println("duplicate no is :" + duplicateNumberFind.findDuplicateInArray(arr));

	}

}
