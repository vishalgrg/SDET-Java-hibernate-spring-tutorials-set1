package Utility;

import java.util.Date;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import beans.EmpDetails;
import beans.Employee;

public class EmployeesDao {

	public List<Employee> getEmployeeList() {

		Session session = null;
		List<Employee> empList = null;
		try {
			session = HibernateUtil.getSession();
			String queryStr = "select emp from Employee emp";
			Query query = session.createQuery(queryStr);
			empList = query.list();
		} catch (Exception ex) {
			ex.printStackTrace();
			// handle exception here
		} finally {
			try {
				if (session != null)
					session.close();
			} catch (Exception ex) {
			}
		}
		return empList;
	}

	public void insertEmployee(Employee emp) {

		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtil.getSession();
			transaction = session.beginTransaction();
			session.merge(emp);
			System.out.println("inserted employee: " + emp.getName());
			transaction.commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			// handle exception here
			if (transaction != null)
				transaction.rollback();
		} finally {
			try {
				if (session != null)
					session.close();
			} catch (Exception ex) {
			}
		}
	}

	public static void main(String a[]) {

		EmployeesDao empDao = new EmployeesDao();

		Employee emp = new Employee();
		EmpDetails emp_details = new EmpDetails();
		emp_details.setAddress("mumbai");
		emp_details.setBankAccount("746489654564");
		emp_details.setGender("male");
		emp_details.setYearsOfService(2018l);

		emp.setName("vishal");
		emp.setDepartment("Security");
		emp.setJoinedOn(new Date());
		emp.setSalary(new Long(5250 * 10));
		
		emp.setEmpDetails(emp_details);
		emp_details.setEmployee(emp);
		
		empDao.insertEmployee(emp);

		System.out.println("---------------------------");

		List<Employee> empList = empDao.getEmployeeList();
		empList.stream().forEach(System.out::println);

		System.out.println("---------------------------");
	}

}