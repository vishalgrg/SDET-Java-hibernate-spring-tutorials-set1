package ques_1;

public class ReverseSinglyLinkedList {
	
	
	//  reverse Singly Linked List 
	
	static Node head;
	
	static class Node{
		
		int data;
		Node next;
		
		Node(int d){
			data = d;
			next = null;
			
		}
		
	}

	
	/* function for reverse linked list*/
	
	Node reverseNodeList(Node node){
	
		Node prev = null;
		Node current = node;
		Node next = null;
		
		while(current != null){
			
			next = current.next;
			current.next = prev;
			prev = current;
			current = next;
			
			
		}
		
		node = prev;
		return node;
	}
	
	/* for printing the list*/
	
	private void printList(Node node){
		while(node!=null ){
			System.out.println(node.data +" ");
			node = node.next;
		}
	}
	public static void main(String[] args) {
		 
	 ReverseSinglyLinkedList linkedList = new ReverseSinglyLinkedList();
	 ReverseSinglyLinkedList.head = new Node(85);
	 ReverseSinglyLinkedList.head.next = new Node(75);
	 ReverseSinglyLinkedList.head.next.next  =new Node(8);
	 ReverseSinglyLinkedList.head.next.next.next = new Node(32);
	 
	 
	 System.out.println("Given linked list is :");
	 linkedList.printList(head);
	 head = linkedList.reverseNodeList(head);
	 System.out.println("");
	 System.out.println("reversed linked list is :");
	 linkedList.printList(head);
	

	}

}
