package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.JavaCollections;

public class Test {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("resources/bean.cfg.xml");
		JavaCollections collections = (JavaCollections)context.getBean("javaCollection");
		
		collections.getAddressList();
		collections.getAddressSet();
		collections.getAddressMap();
	}

}
