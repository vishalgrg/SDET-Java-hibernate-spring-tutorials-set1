package Utils;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;

import beans.Country;
import beans.State;



public class DriverClass {

	public static void main(String[] args) {
		  
		    State s1= new State(91, "MP", 92);
	    	State s2= new State(101, "UP", 101);
	    	Set<State> states= new HashSet<State>();
	    	
	    	states.add(s1);
	    	states.add(s2);
	    	
	    	
	    	Country country = new Country(1,"India",states);
	        Session  session = HibernateUtil.getSession();
	        session.beginTransaction();
	 
	        session.persist(country);
	         
	      
	        session.save(country);
	        session.getTransaction().commit();
	         
	       List<Country> countryList = (List<Country>)session.createQuery("from Country ").list();
	        for(Country s: countryList){
	            System.out.println("Details : "+s.getState().size());
	        }
	     
	    
	        session.close();  
	    }
	}

