package beans;

public class Employee {

	private String name;
	private int sal;
	private String address;

	public Employee(String name, int sal) {
		super();
		this.name = name;
		this.sal = sal;
	}

	
	public Employee(String name, String address) {
		super();
		this.name = name;
		this.address = address;
	}


	@Override
	public String toString() {
		return "Employee [name=" + name + ", sal=" + sal + ", address=" + address + "]";
	}

	

}
