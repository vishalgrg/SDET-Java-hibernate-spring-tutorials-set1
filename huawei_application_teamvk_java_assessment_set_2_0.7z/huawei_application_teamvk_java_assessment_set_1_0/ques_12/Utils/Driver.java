package Utils;

import java.util.List;
import java.util.Set;

import org.hibernate.Session;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;


import beans.AssestMng;

import beans.Employee;

public class Driver {

	public List<Employee> getEmployeeList() {

		Session session = null;
		List<Employee> empList = null;
		try {
			session = HibernateUtils.getSession();
			String queryStr = "select emp from Employee emp";
			Query query = session.createQuery(queryStr);
			empList = query.list();
		} catch (Exception ex) {
			ex.printStackTrace();
			// handle exception here
		} finally {
			try {
				if (session != null)
					session.close();
			} catch (Exception ex) {
			}
		}
		return empList;
	}

	
	public void insertEmployee(Employee emp) {

		Session session = null;
		Transaction transaction = null;
		try {
			session = HibernateUtils.getSession();
			transaction = session.beginTransaction();
			session.merge(emp);
			System.out.println("inserted employee: " + emp.getName());
			transaction.commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			// handle exception here
			if (transaction != null)
				transaction.rollback();
		} finally {
			try {
				if (session != null)
					session.close();
			} catch (Exception ex) {
			}
		}
	}

	public static void main(String[] args) {
		Driver driver = new Driver();
		Employee emp1 = new Employee(1, "VISHAL", "TECH", 645640, new Date());
		Employee emp2 = new Employee(2, "RAHUL", "HR",1000000, new Date());
		
		AssestMng s1 = new AssestMng(101, 1, "Mobile", "SAMSUNG",emp1);
		AssestMng s2 = new AssestMng(102, 1, "LAPTOP", "SONY",emp1);
		
		
		AssestMng s3 = new AssestMng(101, 2, "Mobile", "SAMSUNG",emp2);
		AssestMng s4 = new AssestMng(102, 2, "LAPTOP", "SONY",emp2);

		List<AssestMng> assestMngs1 = new ArrayList<>();
		assestMngs1.add(s1);
		assestMngs1.add(s2);
		
		List<AssestMng> assestMngs2 = new ArrayList<>();
		assestMngs2.add(s3);
		assestMngs2.add(s4);
		
		emp1.setAssetMgnt(assestMngs1);
		emp2.setAssetMgnt(assestMngs2);
	
		
		driver.insertEmployee(emp1);
		driver.insertEmployee(emp2);
		

		List<Employee> empList = driver.getEmployeeList();
        System.out.println("emp size: "+empList.size());
        System.out.println("---------------------------");
        empList.stream().forEach(e -> {
            System.out.println(e);
            System.out.println("-- asset given to "+e.getName()+" --");
            e.getAssetMgnt().stream().forEach(System.out::println);
            System.out.println("---------------------------");
        });

	}

}
