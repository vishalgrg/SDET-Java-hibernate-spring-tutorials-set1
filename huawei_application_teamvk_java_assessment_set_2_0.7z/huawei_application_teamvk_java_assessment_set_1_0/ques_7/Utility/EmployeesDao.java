package Utility;

import java.util.Date;
import java.util.List;
 
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
 

import beans.Employee;

public class EmployeesDao {
	 
    public List<Employee> getEmployeeList(){
 
        Session session = null;
        List<Employee> empList = null;
        try {
            session = HibernateUtil.getSession();
            String queryStr = "select emp from Employee emp";
            Query query = session.createQuery(queryStr);
            empList = query.list();
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
        return empList;
    }
    
    public Employee getEmployeeById(Long empId){
    	 
        Session session = null;
        Employee emp = null;
        try {
            session = HibernateUtil.getSession();
            String queryStr = "select emp from Employee emp";
            emp = session.get(Employee.class, empId);
 
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
        return emp;
    }
 
    public void insertEmployee(Employee emp) {
 
        Session session = null;
        Transaction transaction = null;
        try {
            session = HibernateUtil.getSession();
            transaction = session.beginTransaction();
            session.save(emp);
            System.out.println("inserted employee: "+emp.getName());
            transaction.commit();
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(transaction != null) transaction.rollback();
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
    }
 
    public void deleteEmployee(Employee emp) {
 
        Session session = null;
        Transaction transaction = null;
        try {
            session = HibernateUtil.getSession();
            transaction = session.beginTransaction();
            session.delete(emp);
            transaction.commit();
            System.out.println("deleted employee: "+emp.getName());
        } catch(Exception ex) {
            ex.printStackTrace();
            // handle exception here
            if(transaction != null) transaction.rollback();
        } finally {
            try {if(session != null) session.close();} catch(Exception ex) {}
        }
    }
    
    public void updateEmployeeRecord(Employee emp){
    	Session session = null;
    	Transaction transaction  =null;
    	session = HibernateUtil.getSession();
    	transaction  =  session.beginTransaction();
    	 // Creating Transaction Entity
    	EmployeesDao empDao = new EmployeesDao();

    	  
    	emp.setDepartment("Admin");
    	emp.setSalary(10000l);
    	session.update(emp);
    	transaction.commit();
    	
    	System.out.println("updated employee: "+emp.getName());
    }
    
 
    public static void main(String a[]) {
 
        EmployeesDao empDao = new EmployeesDao();
 
        Employee emp = new Employee();
        
        for(int i = 0; i<6;i++){
        emp.setName("vishal"+i);
        emp.setDepartment("Security"+i);
        emp.setJoinedOn(new Date());
        emp.setSalary(new Long(5250+i*10));
        empDao.insertEmployee(emp);
        }
 
        System.out.println("---------------------------");
 
        List<Employee> empList = empDao.getEmployeeList();
        System.out.println("emp size: "+empList.size());
        empList.stream().forEach(System.out::println);
        
        
        System.out.println("---------- update operation -----------------");
 
        Employee empObj1 = empDao.getEmployeeById(1l);
        System.out.println(empObj1);
        empDao.updateEmployeeRecord(empObj1);
        System.out.println("---------after update record ------------------");
        
        empList = empDao.getEmployeeList();
        System.out.println("emp size: "+empList.size());
        empList.stream().forEach(System.out::println);
        
        
        
        System.out.println("---------- delete operation -----------------");
 
        Employee empObj = empDao.getEmployeeById(5l);
        System.out.println(empObj);
        
        System.out.println("---------------------------");
        empDao.deleteEmployee(empObj);
 
        System.out.println("---------after delete ------------------");
 
        empList = empDao.getEmployeeList();
        System.out.println("emp size: "+empList.size());
        empList.stream().forEach(System.out::println);
 
        System.out.println("---------------------------");
    }
    
}