package Utility;

import java.util.List;

import org.hibernate.Session;

import beans.Address;
import beans.Student;

public class DriverClass {

	public static void main(String[] args) {
		    Student student = new Student("VISHAL","GARG","Maths");
	        Address address = new Address("10 street","MUMBAI","INDIA");
	        Session  session = HibernateUtil.getSession();
	        session.beginTransaction();
	 
	        session.persist(student);
	         
	        address.setId(student.getId());
	        student.setAddress(address);
	        session.save(student);
	         
	        List<Student> students = (List<Student>)session.createQuery("from Student ").list();
	        for(Student s: students){
	            System.out.println("Details : "+s);
	        }
	         
	        session.getTransaction().commit();
	        session.close();  
	    }
	}

