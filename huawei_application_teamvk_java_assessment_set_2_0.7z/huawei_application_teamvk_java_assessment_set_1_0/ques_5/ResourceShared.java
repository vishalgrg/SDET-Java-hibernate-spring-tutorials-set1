package ques_5;

public class ResourceShared {
	
	synchronized void test1(ResourceShared s1){
		System.out.println("test 1 is start");
		Utils.sleep(1000);
		s1.test2(this);
		System.out.println("test 1 is end");
		
	}
	
	synchronized void test2(ResourceShared s2){
		System.out.println("test 2 is start");
		Utils.sleep(1000);
		s2.test1(this);
		System.out.println("test 2 is end");
}
}
