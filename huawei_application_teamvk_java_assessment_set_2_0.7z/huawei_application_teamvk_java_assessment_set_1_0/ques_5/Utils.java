package ques_5;

public class Utils {
	
	// this class used for thread sleep
	
	
	static void sleep(long millis){
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
	}

}
