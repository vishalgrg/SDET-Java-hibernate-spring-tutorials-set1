package ques_5;

public class DeadlockDemo {
	//Write a program to create deadlock between two threads.
	
	
	public static void main(String[] args) {
		 // creating one object 
	    ResourceShared s1 = new ResourceShared(); 

	    // creating second object 
	    ResourceShared s2 = new ResourceShared(); 

	    // creating first thread and starting it 
	    Thread1 t1 = new Thread1(s1, s2); 
	    t1.start(); 

	    // creating second thread and starting it 
	    Thread2 t2 = new Thread2(s1, s2); 
	    t2.start(); 

	    // sleeping main thread 
	   // Utils.sleep(2000); 
	}
	
	
}
