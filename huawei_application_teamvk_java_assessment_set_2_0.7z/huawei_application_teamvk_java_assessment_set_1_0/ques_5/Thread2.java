package ques_5;

public class Thread2 extends Thread {
	private ResourceShared resourceShared_1;
    private ResourceShared resourceShared_2;
	
	public Thread2(ResourceShared resourceShared_1, ResourceShared resourceShared_2) {
		this.resourceShared_1 = resourceShared_1;
		this.resourceShared_2 = resourceShared_2;
	}
	
	@Override
	public void run() {
		
		resourceShared_1.test2(resourceShared_2);;
	}
}
