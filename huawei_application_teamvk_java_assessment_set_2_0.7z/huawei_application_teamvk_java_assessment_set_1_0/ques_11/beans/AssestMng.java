package beans;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ASSET_MNGT")
public class AssestMng implements Serializable {
 
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="AM_ID", unique = true, nullable = false)
    private int amId;
 
    @Column(name="EMP_ID")
    private int empId;
 
    @Column(name="ASSET_NAME")
    private String assetName;
 
    private String vendor;
    
    
    public AssestMng(){
    }

	public AssestMng(int amId, int empId, String assetName, String vendor) {
		this.amId = amId;
		this.empId = empId;
		this.assetName = assetName;
		this.vendor = vendor;
	}

	public int getAmId() {
		return amId;
	}

	public void setAmId(int amId) {
		this.amId = amId;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getAssetName() {
		return assetName;
	}

	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String toString() {
		 
        return this.assetName+" | "+this.vendor;
    }
	
	
}
